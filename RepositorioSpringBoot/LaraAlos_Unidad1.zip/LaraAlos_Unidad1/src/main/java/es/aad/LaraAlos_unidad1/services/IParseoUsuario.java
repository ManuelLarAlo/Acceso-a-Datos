package es.aad.LaraAlos_unidad1.services;

import java.util.Scanner;

import es.aad.LaraAlos_unidad1.utils.BibliotecaException;

public class IParseoUsuario 
{
	
	void parseaFichero(Scanner scanner) throws BibliotecaException{
		
	}

}
