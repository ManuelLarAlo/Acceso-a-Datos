package es.iesjandula.ejercicio.utils;

public class Constants {

	public final static String DELIMITADOR_CSV=",";
	
}
