package es.iesjandula.ejercicio.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.iesjandula.ejercicio.models.Asignatura;

public interface AsignaturaRepository extends JpaRepository<Asignatura,Long> {

}
