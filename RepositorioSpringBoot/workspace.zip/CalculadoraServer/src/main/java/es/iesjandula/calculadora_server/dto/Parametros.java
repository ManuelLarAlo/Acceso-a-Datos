package es.iesjandula.calculadora_server.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Parametros {

	private int numero1;
	public int numero2;
	
}
