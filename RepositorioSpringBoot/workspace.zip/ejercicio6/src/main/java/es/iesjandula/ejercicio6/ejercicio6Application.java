package es.iesjandula.ejercicio6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ejercicio6Application {

	public static void main(String[] args) {
		SpringApplication.run(ejercicio6Application.class, args);
	}

}
