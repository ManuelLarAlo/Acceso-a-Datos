package es.iesjandula.AAD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AadApplicationTests {

	@Test
	void contextLoads() {
	}

}
