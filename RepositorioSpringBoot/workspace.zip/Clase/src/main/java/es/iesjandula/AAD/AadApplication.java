package es.iesjandula.AAD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AadApplication {

	public static void main(String[] args) {
		SpringApplication.run(AadApplication.class, args);
	}

}
