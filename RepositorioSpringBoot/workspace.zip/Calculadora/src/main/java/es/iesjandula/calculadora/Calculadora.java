package es.iesjandula.calculadora;

public class Calculadora {
	
	Calculadora(){
		
	}

	public int suma(int a, int b) {
		return a+b;
	}
	public int resta(int a, int b) {
		return a-b;
	}
	public int multiplicacion(int a, int b) {
		return a*b;
	}
	public int division(int a, int b) {
		return a/b;
	}

}
