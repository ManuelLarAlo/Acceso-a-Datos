package es.iesjandula.ejercicio5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ejercicio5Application {

	public static void main(String[] args) {
		SpringApplication.run(ejercicio5Application.class, args);
	}

}
