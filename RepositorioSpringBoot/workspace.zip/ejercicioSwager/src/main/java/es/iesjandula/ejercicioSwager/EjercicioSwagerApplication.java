package es.iesjandula.ejercicioSwager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioSwagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioSwagerApplication.class, args);
	}

}
