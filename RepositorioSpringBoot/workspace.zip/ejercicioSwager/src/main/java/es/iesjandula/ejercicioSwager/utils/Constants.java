package es.iesjandula.ejercicioSwager.utils;

public class Constants {

	public final static String DELIMITADOR_CSV=",";
	
}
