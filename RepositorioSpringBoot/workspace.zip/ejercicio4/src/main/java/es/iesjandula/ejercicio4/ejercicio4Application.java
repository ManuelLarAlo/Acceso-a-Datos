package es.iesjandula.ejercicio4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ejercicio4Application {

	public static void main(String[] args) {
		SpringApplication.run(ejercicio4Application.class, args);
	}

}
